-- phpMyAdmin SQL Dump
-- version 4.6.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 06-05-2018 a las 00:45:28
-- Versión del servidor: 5.7.12-log
-- Versión de PHP: 5.6.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `carnet-iutcm`
--
CREATE DATABASE IF NOT EXISTS `carnet-iutcm` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `carnet-iutcm`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumcarnet`
--

DROP TABLE IF EXISTS `alumcarnet`;
CREATE TABLE `alumcarnet` (
  `Cedula` int(11) NOT NULL,
  `idNacion` int(11) NOT NULL,
  `Nombres` varchar(50) NOT NULL,
  `Apellidos` varchar(50) NOT NULL,
  `idSexo` int(11) NOT NULL,
  `telefono` varchar(50) NOT NULL,
  `correo` varchar(50) NOT NULL,
  `FechaReg` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `alumcarnet`
--

INSERT INTO `alumcarnet` (`Cedula`, `idNacion`, `Nombres`, `Apellidos`, `idSexo`, `telefono`, `correo`, `FechaReg`) VALUES
(9399472, 1, 'Carmen Zuleima', 'Escalante Lara', 1, '0412-4269760', 'iutcm@gmail.com', '2018-04-10'),
(15669168, 1, 'Esperanza ', 'Diaz', 1, '0274-2633049', 'esperanza.diaz@iutcm.edu.ve', '2018-04-20'),
(23303527, 1, 'Jorge', 'Morantes', 2, '0241-3216545', 'iutcm@gmail.com', '2018-01-23'),
(23541545, 1, 'Ana Gabriela', 'Suarez Varela', 1, '0426-5421455', 'iutcm@gmail.com', '2017-11-29'),
(24148743, 1, 'Jean', 'Escalante', 2, '0426-5421455', 'ghsgh@gmail.com', '2018-01-19');

--
-- Disparadores `alumcarnet`
--
DROP TRIGGER IF EXISTS `trigger_alumcarnet_del`;
DELIMITER $$
CREATE TRIGGER `trigger_alumcarnet_del` AFTER DELETE ON `alumcarnet` FOR EACH ROW INSERT INTO bitacora (Cedula, Nombres, Usuario, Modificado, Accion, Tabla) VALUES (OLD.Cedula, OLD.Nombres, CURRENT_USER(), NOW(), 'Borrado' , 'alumcarnet')
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `trigger_alumcarnet_ins`;
DELIMITER $$
CREATE TRIGGER `trigger_alumcarnet_ins` AFTER INSERT ON `alumcarnet` FOR EACH ROW INSERT INTO bitacora (Cedula, Nombres, Usuario, Modificado, Accion, Tabla) VALUES (NEW.Cedula, NEW.Nombres, CURRENT_USER(), NOW(), 'Guardado' , 'alumcarnet')
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `trigger_alumcarnet_upd`;
DELIMITER $$
CREATE TRIGGER `trigger_alumcarnet_upd` AFTER UPDATE ON `alumcarnet` FOR EACH ROW INSERT INTO bitacora (Cedula, Nombres, Usuario, Modificado, Accion, Tabla) VALUES (OLD.Cedula, OLD.Nombres, CURRENT_USER(), NOW(), 'Editado' , 'alumcarnet')
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `bitacora`
--

DROP TABLE IF EXISTS `bitacora`;
CREATE TABLE `bitacora` (
  `id` int(11) NOT NULL,
  `Cedula` varchar(50) DEFAULT NULL,
  `Nombres` varchar(50) DEFAULT NULL,
  `Usuario` varchar(40) DEFAULT NULL,
  `Modificado` datetime DEFAULT NULL,
  `Accion` varchar(100) DEFAULT NULL,
  `Tabla` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `bitacora`
--

INSERT INTO `bitacora` (`id`, `Cedula`, `Nombres`, `Usuario`, `Modificado`, `Accion`, `Tabla`) VALUES
(1, '24148743', 'Jean Carlos', 'root@localhost', '2018-05-05 08:18:06', 'Borrado', 'personalcarnet'),
(2, '24148743', 'Jean Carlos', 'root@localhost', '2018-05-05 14:24:29', 'Guardado', 'personalcarnet'),
(3, '23497418', 'Fabricio', 'root@localhost', '2018-05-05 16:44:45', 'Guardado', 'personalcarnet');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cargo`
--

DROP TABLE IF EXISTS `cargo`;
CREATE TABLE `cargo` (
  `CodCargo` int(11) NOT NULL,
  `Cargo` varchar(100) NOT NULL,
  `idTipoCarg` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `cargo`
--

INSERT INTO `cargo` (`CodCargo`, `Cargo`, `idTipoCarg`) VALUES
(1, 'Docente', 1),
(2, 'Asistente Administrativo', 2),
(3, 'Coordinador de Informatica', 2),
(4, 'Docente Fijo', 1),
(5, 'Mantenimiento', 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carrera`
--

DROP TABLE IF EXISTS `carrera`;
CREATE TABLE `carrera` (
  `CodCarrera` int(11) NOT NULL,
  `Carrera` varchar(50) NOT NULL,
  `idFormato` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `carrera`
--

INSERT INTO `carrera` (`CodCarrera`, `Carrera`, `idFormato`) VALUES
(1, 'Administración', 2),
(2, 'Informática', 1),
(8, 'Turismo', 8),
(10, 'Agropecuaria', 12);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estatus`
--

DROP TABLE IF EXISTS `estatus`;
CREATE TABLE `estatus` (
  `idEstatus` int(11) NOT NULL,
  `Estatus` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `estatus`
--

INSERT INTO `estatus` (`idEstatus`, `Estatus`) VALUES
(1, 'Solicitado'),
(2, 'Entregado'),
(3, 'Reclamo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `formatcarnet`
--

DROP TABLE IF EXISTS `formatcarnet`;
CREATE TABLE `formatcarnet` (
  `idFormato` int(11) NOT NULL,
  `FormatCarnet` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `formatcarnet`
--

INSERT INTO `formatcarnet` (`idFormato`, `FormatCarnet`) VALUES
(1, '1.png'),
(2, '2.png'),
(8, '3.png'),
(9, 'Formato-administrativo(1).png'),
(10, 'Formato-docente(2).png'),
(12, 'academico.png');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `login`
--

DROP TABLE IF EXISTS `login`;
CREATE TABLE `login` (
  `Usuario` varchar(50) NOT NULL,
  `Cont` varchar(250) NOT NULL,
  `PregSeg` varchar(50) NOT NULL,
  `RespuSeg` varchar(50) NOT NULL,
  `Correo` varchar(50) NOT NULL,
  `Bloqueo` tinyint(1) NOT NULL,
  `idBitacora` int(11) NOT NULL,
  `idNivel` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `login`
--

INSERT INTO `login` (`Usuario`, `Cont`, `PregSeg`, `RespuSeg`, `Correo`, `Bloqueo`, `idBitacora`, `idNivel`) VALUES
('root', '1f82ea75c5cc526729e2d581aeb3aeccfef4407e', '1', '1', 'iutcm@gmail.com', 0, 0, 1),
('usuario', 'adcd7048512e64b48da55b027577886ee5a36350', '1', '1', 'iutcm212@gmail.com', 0, 0, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `movimient`
--

DROP TABLE IF EXISTS `movimient`;
CREATE TABLE `movimient` (
  `idMov` int(11) NOT NULL,
  `idPro` int(11) NOT NULL,
  `CantiMov` int(11) NOT NULL,
  `idTipoMov` int(11) NOT NULL,
  `Fecha` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `movimient`
--

INSERT INTO `movimient` (`idMov`, `idPro`, `CantiMov`, `idTipoMov`, `Fecha`) VALUES
(3, 1, 100, 1, '2018-02-06'),
(4, 1, 50, 1, '2018-02-22'),
(5, 1, 100, 1, '2018-02-27'),
(6, 1, 2, 1, '2018-02-27'),
(7, 1, 1, 2, '2018-02-27'),
(8, 1, 1, 2, '2018-02-27'),
(9, 1, 1, 2, '2018-02-27'),
(10, 1, 1, 2, '2018-02-27'),
(11, 1, 1, 2, '2018-02-27'),
(12, 1, 1, 2, '2018-02-27'),
(13, 1, 1, 2, '2018-02-27'),
(14, 1, 1, 2, '2018-02-27'),
(15, 1, 1, 1, '2018-04-20'),
(16, 1, 1, 1, '2018-04-20'),
(17, 1, 10, 1, '2018-04-19'),
(18, 1, 10, 1, '2018-04-19'),
(19, 1, 1, 2, '2018-04-19'),
(20, 1, 1, 2, '2018-04-19'),
(21, 1, 1, 2, '2018-04-19'),
(22, 1, 1, 2, '2018-04-19'),
(23, 1, 1, 2, '2018-04-19'),
(24, 1, 1, 2, '2018-04-19'),
(25, 1, 1, 2, '2018-04-19'),
(26, 1, 1, 2, '2018-04-19'),
(27, 1, 1, 2, '2018-04-19'),
(28, 1, 1, 2, '2018-04-19'),
(29, 1, 1, 2, '2018-04-19'),
(30, 1, 1, 2, '2018-04-19'),
(31, 1, 1, 2, '2018-04-19'),
(32, 1, 1, 2, '2018-04-19'),
(33, 1, 1, 2, '2018-04-19'),
(34, 1, 1, 2, '2018-04-19'),
(35, 1, 1, 2, '2018-04-19'),
(36, 1, 1, 2, '2018-04-19'),
(37, 1, 1, 2, '2018-04-19'),
(38, 1, 1, 2, '2018-04-19'),
(39, 1, 1, 2, '2018-04-19'),
(40, 1, 1, 2, '2018-04-19'),
(41, 1, 1, 2, '2018-04-19'),
(42, 1, 1, 2, '2018-04-19'),
(43, 1, 1, 2, '2018-04-19'),
(44, 1, 1, 2, '2018-04-19'),
(45, 1, 1, 2, '2018-04-19'),
(46, 1, 1, 2, '2018-04-19'),
(47, 1, 1, 2, '2018-04-19'),
(48, 1, 1, 2, '2018-04-19'),
(49, 1, 1, 2, '2018-04-19'),
(50, 1, 1, 2, '2018-04-19'),
(51, 1, 1, 2, '2018-04-19'),
(52, 1, 1, 2, '2018-04-19'),
(53, 1, 1, 2, '2018-04-19'),
(54, 1, 1, 2, '2018-04-19'),
(55, 1, 1, 2, '2018-04-19'),
(56, 1, 1, 2, '2018-04-19'),
(57, 1, 1, 2, '2018-04-19'),
(58, 1, 1, 2, '2018-04-19'),
(59, 1, 1, 2, '2018-04-19'),
(60, 1, 1, 2, '2018-04-19'),
(61, 1, 1, 2, '2018-04-19'),
(62, 1, 1, 2, '2018-04-19'),
(63, 1, 1, 2, '2018-04-19'),
(64, 1, 1, 2, '2018-04-19'),
(65, 1, 1, 2, '2018-04-19'),
(66, 1, 1, 2, '2018-04-19'),
(67, 1, 1, 2, '2018-04-19'),
(68, 1, 1, 2, '2018-04-19'),
(69, 1, 1, 2, '2018-04-19'),
(70, 1, 1, 2, '2018-04-19'),
(71, 1, 1, 2, '2018-04-19'),
(72, 1, 1, 2, '2018-04-19'),
(73, 1, 1, 2, '2018-04-19'),
(74, 1, 1, 2, '2018-04-19'),
(75, 1, 1, 2, '2018-04-19'),
(76, 1, 1, 2, '2018-04-19'),
(77, 1, 1, 2, '2018-04-19'),
(78, 1, 1, 2, '2018-04-19'),
(79, 1, 1, 2, '2018-04-19'),
(80, 1, 1, 2, '2018-04-19'),
(81, 1, 1, 2, '2018-04-20'),
(82, 1, 1, 2, '2018-04-20'),
(83, 1, 1, 2, '2018-05-04'),
(84, 1, 1, 2, '2018-05-05'),
(85, 1, 1, 2, '2018-05-05'),
(86, 1, 1, 2, '2018-05-05'),
(87, 1, 1, 2, '2018-05-05'),
(88, 1, 1, 2, '2018-05-05'),
(89, 1, 1, 2, '2018-05-05'),
(90, 1, 1, 2, '2018-05-05'),
(91, 1, 1, 2, '2018-05-05');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `nacion`
--

DROP TABLE IF EXISTS `nacion`;
CREATE TABLE `nacion` (
  `idNacion` int(11) NOT NULL,
  `Nacion` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `nacion`
--

INSERT INTO `nacion` (`idNacion`, `Nacion`) VALUES
(1, 'Venezolano'),
(2, 'Extranjero');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `nivel`
--

DROP TABLE IF EXISTS `nivel`;
CREATE TABLE `nivel` (
  `idNivel` int(11) NOT NULL,
  `Nivel` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `nivel`
--

INSERT INTO `nivel` (`idNivel`, `Nivel`) VALUES
(1, 'Administrador'),
(2, 'Usuario');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `personalcarnet`
--

DROP TABLE IF EXISTS `personalcarnet`;
CREATE TABLE `personalcarnet` (
  `CedulaPerso` int(11) NOT NULL,
  `idNacion` int(11) NOT NULL,
  `Nombres` varchar(50) NOT NULL,
  `Apellidos` varchar(50) NOT NULL,
  `idSexo` int(11) NOT NULL,
  `telefono` varchar(50) NOT NULL,
  `correo` varchar(50) NOT NULL,
  `FechaReg` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `personalcarnet`
--

INSERT INTO `personalcarnet` (`CedulaPerso`, `idNacion`, `Nombres`, `Apellidos`, `idSexo`, `telefono`, `correo`, `FechaReg`) VALUES
(8705420, 1, 'Alis Margarita', 'Varela Chacon', 1, '0412-0000000', 'iutcm212@gmail.com', '2018-02-28'),
(23497418, 1, 'Fabricio', 'Rodriguez', 2, '0412-0000000', 'iutcm212@gmail.com', '2018-05-05'),
(24148743, 1, 'Jean Carlos', 'Escalante Lara', 2, '0233-2332323', 'iutcm212@gmail.com', '2018-05-05');

--
-- Disparadores `personalcarnet`
--
DROP TRIGGER IF EXISTS `trigger_personalcarnet_del`;
DELIMITER $$
CREATE TRIGGER `trigger_personalcarnet_del` AFTER DELETE ON `personalcarnet` FOR EACH ROW INSERT INTO bitacora (Cedula, Nombres, Usuario, Modificado, Accion, Tabla) VALUES (OLD.CedulaPerso, OLD.Nombres, CURRENT_USER(), NOW(), 'Borrado' , 'personalcarnet')
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `trigger_personalcarnet_ins`;
DELIMITER $$
CREATE TRIGGER `trigger_personalcarnet_ins` AFTER INSERT ON `personalcarnet` FOR EACH ROW INSERT INTO bitacora (Cedula, Nombres, Usuario, Modificado, Accion, Tabla) VALUES (NEW.CedulaPerso, NEW.Nombres, CURRENT_USER(), NOW(), 'Guardado' , 'personalcarnet')
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `trigger_personalcarnet_upd`;
DELIMITER $$
CREATE TRIGGER `trigger_personalcarnet_upd` AFTER UPDATE ON `personalcarnet` FOR EACH ROW INSERT INTO bitacora (Cedula, Nombres, Usuario, Modificado, Accion, Tabla) VALUES (OLD.CedulaPerso, OLD.Nombres, CURRENT_USER(), NOW(), 'Editado' , 'personalcarnet')
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

DROP TABLE IF EXISTS `producto`;
CREATE TABLE `producto` (
  `idPro` int(11) NOT NULL,
  `Nombre` varchar(50) NOT NULL,
  `CantExiste` int(11) NOT NULL,
  `Descrip` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `producto`
--

INSERT INTO `producto` (`idPro`, `Nombre`, `CantExiste`, `Descrip`) VALUES
(1, 'Pastas', 194, 'Pastas de  pvc 			\r\n																																		');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `regcarnetalum`
--

DROP TABLE IF EXISTS `regcarnetalum`;
CREATE TABLE `regcarnetalum` (
  `idCarnetAlum` int(11) NOT NULL,
  `Cedula` int(11) NOT NULL,
  `CodCarrera` int(11) NOT NULL,
  `CodSemes` int(11) NOT NULL,
  `CodTurno` int(11) NOT NULL,
  `NPago` int(11) NOT NULL,
  `FechaSol` date NOT NULL,
  `FechaEntre` date NOT NULL,
  `FechaVen` date NOT NULL,
  `idEstatus` int(11) NOT NULL,
  `Foto` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `regcarnetalum`
--

INSERT INTO `regcarnetalum` (`idCarnetAlum`, `Cedula`, `CodCarrera`, `CodSemes`, `CodTurno`, `NPago`, `FechaSol`, `FechaEntre`, `FechaVen`, `idEstatus`, `Foto`) VALUES
(4, 23541545, 1, 1, 1, 2254566, '2017-11-29', '2018-02-07', '2018-10-31', 2, 'C:/AppServ/www/carnet-iutcm/Fotos/Foto-Estudiantes/24148743'),
(6, 23541545, 2, 6, 1, 2254566, '2017-11-30', '2018-02-27', '2018-03-01', 2, 'C:/AppServ/www/carnet-iutcm/Fotos/Foto-Estudiantes/23541545'),
(9, 23303527, 2, 6, 1, 322125, '2018-01-23', '2018-05-05', '2018-05-18', 2, 'C:/AppServ/www/carnet-iutcm/Fotos/Foto-Estudiantes/23303527'),
(12, 15669168, 1, 6, 1, 123456, '2018-04-20', '2018-04-20', '2018-10-31', 2, 'C:/AppServ/www/carnet-iutcm/Fotos/Foto-Estudiantes/15669168'),
(13, 24148743, 1, 6, 1, 123456, '2018-04-20', '2018-04-20', '2018-04-20', 2, 'C:/AppServ/www/carnet-iutcm/Fotos/Foto-Estudiantes/24148743'),
(14, 23541545, 2, 5, 1, 123456, '2018-04-20', '2018-05-05', '2018-07-13', 2, 'C:/AppServ/www/carnet-iutcm/Fotos/Foto-Estudiantes/23541545'),
(15, 23303527, 2, 5, 1, 123456, '2018-04-20', '2018-05-05', '2018-05-18', 2, 'C:/AppServ/www/carnet-iutcm/Fotos/Foto-Estudiantes/23303527');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `regcarnetper`
--

DROP TABLE IF EXISTS `regcarnetper`;
CREATE TABLE `regcarnetper` (
  `idCarnetPer` int(11) NOT NULL,
  `CedulaPerso` int(11) NOT NULL,
  `CodCargo` int(11) NOT NULL,
  `idTipoCarg` int(11) NOT NULL,
  `FechaSol` date NOT NULL,
  `FechaEntre` date NOT NULL,
  `idEstatus` int(11) NOT NULL,
  `Foto` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `regcarnetper`
--

INSERT INTO `regcarnetper` (`idCarnetPer`, `CedulaPerso`, `CodCargo`, `idTipoCarg`, `FechaSol`, `FechaEntre`, `idEstatus`, `Foto`) VALUES
(2, 8705420, 4, 1, '2018-02-28', '2018-05-05', 2, 'C:/AppServ/www/carnet-iutcm/Fotos/Foto-Personal/8705420'),
(5, 24148743, 5, 2, '2018-05-05', '2018-05-05', 1, 'C:/AppServ/www/carnet-iutcm/Fotos/Foto-Personal/24148743'),
(6, 23497418, 4, 1, '2018-05-05', '2018-05-05', 2, 'C:/AppServ/www/carnet-iutcm/Fotos/Foto-Personal/23497418');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `semestre`
--

DROP TABLE IF EXISTS `semestre`;
CREATE TABLE `semestre` (
  `CodSemes` int(11) NOT NULL,
  `Semes` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `semestre`
--

INSERT INTO `semestre` (`CodSemes`, `Semes`) VALUES
(1, 'Semestre 1'),
(2, 'Semestre 2'),
(3, 'Semestre 3'),
(4, 'Semestre 4'),
(5, 'Semestre 5'),
(6, 'Semestre 6');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sexo`
--

DROP TABLE IF EXISTS `sexo`;
CREATE TABLE `sexo` (
  `idSexo` int(11) NOT NULL,
  `Sexo` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `sexo`
--

INSERT INTO `sexo` (`idSexo`, `Sexo`) VALUES
(1, 'Femenino'),
(2, 'Masculino');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipocargo`
--

DROP TABLE IF EXISTS `tipocargo`;
CREATE TABLE `tipocargo` (
  `idTipoCarg` int(11) NOT NULL,
  `NomTipoCarg` varchar(100) NOT NULL,
  `idFormato` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `tipocargo`
--

INSERT INTO `tipocargo` (`idTipoCarg`, `NomTipoCarg`, `idFormato`) VALUES
(1, 'Personal ', 10),
(2, 'Personal Administrativo', 9);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipomov`
--

DROP TABLE IF EXISTS `tipomov`;
CREATE TABLE `tipomov` (
  `idTipoMov` int(11) NOT NULL,
  `TipoMov` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `tipomov`
--

INSERT INTO `tipomov` (`idTipoMov`, `TipoMov`) VALUES
(1, 'Entrada'),
(2, 'Salida');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `turno`
--

DROP TABLE IF EXISTS `turno`;
CREATE TABLE `turno` (
  `CodTurno` int(11) NOT NULL,
  `Turno` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `turno`
--

INSERT INTO `turno` (`CodTurno`, `Turno`) VALUES
(1, 'Matutino'),
(2, 'Vespertino'),
(3, 'Sabatino');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `alumcarnet`
--
ALTER TABLE `alumcarnet`
  ADD PRIMARY KEY (`Cedula`),
  ADD KEY `idNacion` (`idNacion`),
  ADD KEY `idSexo` (`idSexo`);

--
-- Indices de la tabla `bitacora`
--
ALTER TABLE `bitacora`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `cargo`
--
ALTER TABLE `cargo`
  ADD PRIMARY KEY (`CodCargo`),
  ADD KEY `idTipo` (`idTipoCarg`);

--
-- Indices de la tabla `carrera`
--
ALTER TABLE `carrera`
  ADD PRIMARY KEY (`CodCarrera`),
  ADD KEY `idFormato` (`idFormato`);

--
-- Indices de la tabla `estatus`
--
ALTER TABLE `estatus`
  ADD PRIMARY KEY (`idEstatus`);

--
-- Indices de la tabla `formatcarnet`
--
ALTER TABLE `formatcarnet`
  ADD PRIMARY KEY (`idFormato`);

--
-- Indices de la tabla `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`Usuario`),
  ADD KEY `idNivel` (`idNivel`),
  ADD KEY `idBitacora` (`idBitacora`);

--
-- Indices de la tabla `movimient`
--
ALTER TABLE `movimient`
  ADD PRIMARY KEY (`idMov`),
  ADD KEY `idPro` (`idPro`),
  ADD KEY `idTipoMov` (`idTipoMov`);

--
-- Indices de la tabla `nacion`
--
ALTER TABLE `nacion`
  ADD PRIMARY KEY (`idNacion`);

--
-- Indices de la tabla `nivel`
--
ALTER TABLE `nivel`
  ADD PRIMARY KEY (`idNivel`);

--
-- Indices de la tabla `personalcarnet`
--
ALTER TABLE `personalcarnet`
  ADD PRIMARY KEY (`CedulaPerso`),
  ADD KEY `idNacion` (`idNacion`),
  ADD KEY `idSexo` (`idSexo`);

--
-- Indices de la tabla `producto`
--
ALTER TABLE `producto`
  ADD PRIMARY KEY (`idPro`);

--
-- Indices de la tabla `regcarnetalum`
--
ALTER TABLE `regcarnetalum`
  ADD PRIMARY KEY (`idCarnetAlum`),
  ADD KEY `CodCarrera` (`CodCarrera`),
  ADD KEY `CodSemes` (`CodSemes`),
  ADD KEY `CodTurno` (`CodTurno`),
  ADD KEY `idEstatus` (`idEstatus`);

--
-- Indices de la tabla `regcarnetper`
--
ALTER TABLE `regcarnetper`
  ADD PRIMARY KEY (`idCarnetPer`),
  ADD KEY `CodCargo` (`CodCargo`),
  ADD KEY `idTipoCarg` (`idTipoCarg`),
  ADD KEY `idEstatus` (`idEstatus`);

--
-- Indices de la tabla `semestre`
--
ALTER TABLE `semestre`
  ADD PRIMARY KEY (`CodSemes`);

--
-- Indices de la tabla `sexo`
--
ALTER TABLE `sexo`
  ADD PRIMARY KEY (`idSexo`);

--
-- Indices de la tabla `tipocargo`
--
ALTER TABLE `tipocargo`
  ADD PRIMARY KEY (`idTipoCarg`);

--
-- Indices de la tabla `tipomov`
--
ALTER TABLE `tipomov`
  ADD PRIMARY KEY (`idTipoMov`),
  ADD KEY `TipoMov` (`TipoMov`);

--
-- Indices de la tabla `turno`
--
ALTER TABLE `turno`
  ADD PRIMARY KEY (`CodTurno`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `bitacora`
--
ALTER TABLE `bitacora`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `cargo`
--
ALTER TABLE `cargo`
  MODIFY `CodCargo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT de la tabla `carrera`
--
ALTER TABLE `carrera`
  MODIFY `CodCarrera` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT de la tabla `estatus`
--
ALTER TABLE `estatus`
  MODIFY `idEstatus` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `formatcarnet`
--
ALTER TABLE `formatcarnet`
  MODIFY `idFormato` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT de la tabla `movimient`
--
ALTER TABLE `movimient`
  MODIFY `idMov` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=92;
--
-- AUTO_INCREMENT de la tabla `nacion`
--
ALTER TABLE `nacion`
  MODIFY `idNacion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `nivel`
--
ALTER TABLE `nivel`
  MODIFY `idNivel` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `producto`
--
ALTER TABLE `producto`
  MODIFY `idPro` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `regcarnetalum`
--
ALTER TABLE `regcarnetalum`
  MODIFY `idCarnetAlum` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT de la tabla `regcarnetper`
--
ALTER TABLE `regcarnetper`
  MODIFY `idCarnetPer` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT de la tabla `semestre`
--
ALTER TABLE `semestre`
  MODIFY `CodSemes` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT de la tabla `sexo`
--
ALTER TABLE `sexo`
  MODIFY `idSexo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `tipocargo`
--
ALTER TABLE `tipocargo`
  MODIFY `idTipoCarg` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `tipomov`
--
ALTER TABLE `tipomov`
  MODIFY `idTipoMov` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `turno`
--
ALTER TABLE `turno`
  MODIFY `CodTurno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `alumcarnet`
--
ALTER TABLE `alumcarnet`
  ADD CONSTRAINT `alumcarnet_ibfk_1` FOREIGN KEY (`idSexo`) REFERENCES `sexo` (`idSexo`),
  ADD CONSTRAINT `alumcarnet_ibfk_2` FOREIGN KEY (`idNacion`) REFERENCES `nacion` (`idNacion`);

--
-- Filtros para la tabla `cargo`
--
ALTER TABLE `cargo`
  ADD CONSTRAINT `cargo_ibfk_1` FOREIGN KEY (`idTipoCarg`) REFERENCES `tipocargo` (`idTipoCarg`);

--
-- Filtros para la tabla `carrera`
--
ALTER TABLE `carrera`
  ADD CONSTRAINT `carrera_ibfk_1` FOREIGN KEY (`idFormato`) REFERENCES `formatcarnet` (`idFormato`);

--
-- Filtros para la tabla `login`
--
ALTER TABLE `login`
  ADD CONSTRAINT `login_ibfk_1` FOREIGN KEY (`idNivel`) REFERENCES `nivel` (`idNivel`);

--
-- Filtros para la tabla `movimient`
--
ALTER TABLE `movimient`
  ADD CONSTRAINT `movimient_ibfk_1` FOREIGN KEY (`idTipoMov`) REFERENCES `tipomov` (`idTipoMov`),
  ADD CONSTRAINT `movimient_ibfk_2` FOREIGN KEY (`idPro`) REFERENCES `producto` (`idPro`);

--
-- Filtros para la tabla `personalcarnet`
--
ALTER TABLE `personalcarnet`
  ADD CONSTRAINT `personalcarnet_ibfk_1` FOREIGN KEY (`idNacion`) REFERENCES `nacion` (`idNacion`),
  ADD CONSTRAINT `personalcarnet_ibfk_2` FOREIGN KEY (`idSexo`) REFERENCES `sexo` (`idSexo`);

--
-- Filtros para la tabla `regcarnetalum`
--
ALTER TABLE `regcarnetalum`
  ADD CONSTRAINT `regcarnetalum_ibfk_1` FOREIGN KEY (`CodSemes`) REFERENCES `semestre` (`CodSemes`),
  ADD CONSTRAINT `regcarnetalum_ibfk_2` FOREIGN KEY (`CodTurno`) REFERENCES `turno` (`CodTurno`),
  ADD CONSTRAINT `regcarnetalum_ibfk_3` FOREIGN KEY (`CodCarrera`) REFERENCES `carrera` (`CodCarrera`),
  ADD CONSTRAINT `regcarnetalum_ibfk_4` FOREIGN KEY (`idEstatus`) REFERENCES `estatus` (`idEstatus`);

--
-- Filtros para la tabla `regcarnetper`
--
ALTER TABLE `regcarnetper`
  ADD CONSTRAINT `regcarnetper_ibfk_1` FOREIGN KEY (`idEstatus`) REFERENCES `estatus` (`idEstatus`),
  ADD CONSTRAINT `regcarnetper_ibfk_2` FOREIGN KEY (`CodCargo`) REFERENCES `cargo` (`CodCargo`),
  ADD CONSTRAINT `regcarnetper_ibfk_3` FOREIGN KEY (`idTipoCarg`) REFERENCES `tipocargo` (`idTipoCarg`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
